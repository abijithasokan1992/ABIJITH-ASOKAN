# StreamVista FACTORY Support Layer

This directory is the shared support layer for StreamVista software, tools, MCPs, agents and operational workflows. It is intentionally isolated from product runtime code so that FACTORY organization can evolve without destabilizing production applications.

## Governing rules
1. Factory hierarchy
2. Golden Baseline before production promotion
3. **Mandatory Pre-Domain QA Gate:** no production domain mapping, DNS cutover, production promotion, or `live` claim until all intended production app pages and critical workflows are complete, correctly wired, pass the required QA gates, and have release evidence. See [`operations/MASTER_PRE_DOMAIN_QA_GATE.md`](operations/MASTER_PRE_DOMAIN_QA_GATE.md).
4. Never rebuild. Always compose: Search -> Reuse -> Wire -> Verify -> Ship
5. Revenue first
6. Evidence only for completion claims
7. **Zero-Stall Blocker + Present/Future Revenue Law:** a blocker is a routing signal, not permission to idle. Stop repeating a dead path, immediately search a compatible verified capability, synthesize and execute a safe bypass/repair/replacement when needed, operate from present verified truth, use past failures as future intelligence, and begin revenue execution from the verified release moment. See [`knowledge/ZERO_STALL_BLOCKER_REVENUE_LAW.md`](knowledge/ZERO_STALL_BLOCKER_REVENUE_LAW.md).

## Layers
- `platform/` shared capabilities
- `products/` product manifests and links
- `agents/` reusable agent specifications
- `tools/` connectors, MCPs and utilities
- `workforce/` orchestration and state
- `knowledge/` decisions and reusable project intelligence
- `operations/` execution queues and release controls
- `revenue/` money-facing opportunities, sales and payment workflows

## Status model
Every component must use exactly one implementation status:
- `live` - deployed and verified
- `prototype` - runnable partial implementation
- `draft` - specification/design exists, not verified runnable code
- `planned` - intended, not yet implemented

A component must not be promoted to `live` without evidence including repository/ref, verification result and timestamp.
