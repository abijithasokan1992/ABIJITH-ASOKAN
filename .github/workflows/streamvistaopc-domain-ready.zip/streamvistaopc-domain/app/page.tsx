import Link from "next/link";
import Image from "next/image";
import { ArrowRight, Play, Sparkles, Crown, Film, Users } from "lucide-react";
const shows=[
 {title:"Monsoon Signal",meta:"Original Film · Malayalam",img:"https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&w=1400&q=85"},
 {title:"Night Shift Mumbai",meta:"Series · 6 Episodes",img:"https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=1400&q=85"},
 {title:"The Last Cut",meta:"Creator Short · 24 min",img:"https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=1400&q=85"}
];
export default function Home(){
 return <main className="min-h-screen grid-bg">
  <nav className="mx-auto flex max-w-7xl items-center justify-between px-6 py-6">
   <div className="font-black tracking-tight text-xl">STREAM <span className="text-brand">VISTA</span> <span className="text-xs text-white/30">OPC</span></div>
   <div className="flex gap-2"><Link href="/auth" className="rounded-xl px-4 py-2 text-sm text-white/60">Creator login</Link><Link href="/dashboard" className="rounded-xl bg-brand px-4 py-2 text-sm font-bold text-black">Studio</Link></div>
  </nav>
  <section className="mx-auto max-w-7xl px-6 pb-16 pt-16">
   <div className="max-w-4xl"><div className="inline-flex items-center gap-2 rounded-full border border-brand/20 bg-brand/5 px-3 py-1.5 text-xs text-brand"><Sparkles size={13}/> Kerala creator OTT</div>
   <h1 className="mt-6 text-6xl font-black leading-[.94] tracking-[-.055em] md:text-8xl">Stories from<br/><span className="text-white/35">the first frame</span><br/>to the audience.</h1>
   <p className="mt-7 max-w-2xl text-lg leading-8 text-white/50">Stream Vista OPC brings films, series and independent creators into one premium publishing and commerce network.</p>
   <div className="mt-9 flex flex-wrap gap-3"><Link href="/browse" className="rounded-xl bg-brand px-6 py-3 font-bold text-black">Watch originals <ArrowRight className="ml-2 inline" size={17}/></Link><Link href="/auth" className="rounded-xl border border-white/10 bg-white/5 px-6 py-3 font-semibold">Join as creator</Link></div></div>
   <div className="mt-16 grid gap-5 md:grid-cols-3">{shows.map(s=><Link href="/watch/monsoon-signal" className="group overflow-hidden rounded-2xl border border-white/10" key={s.title}><div className="relative h-80"><Image src={s.img} alt={s.title} fill className="object-cover transition duration-700 group-hover:scale-105"/><div className="absolute inset-0 bg-gradient-to-t from-black via-transparent"/><div className="absolute bottom-5 left-5"><div className="text-lg font-bold">{s.title}</div><div className="text-xs text-white/45">{s.meta}</div></div><div className="absolute right-4 top-4 rounded-full bg-black/50 p-3"><Play size={16}/></div></div></Link>)}</div>
   <div className="mt-10 grid gap-4 md:grid-cols-3"><div className="card p-6"><Film className="text-brand"/><h3 className="mt-4 font-bold">Originals</h3><p className="mt-2 text-sm text-white/40">Premium independent cinema and creator series.</p></div><div className="card p-6"><Users className="text-brand"/><h3 className="mt-4 font-bold">Creator economy</h3><p className="mt-2 text-sm text-white/40">Publish, grow, monetize and manage rights.</p></div><div className="card p-6"><Crown className="text-brand"/><h3 className="mt-4 font-bold">Membership</h3><p className="mt-2 text-sm text-white/40">One subscription unlocks the growing library.</p></div></div>
  </section>
 </main>
}
