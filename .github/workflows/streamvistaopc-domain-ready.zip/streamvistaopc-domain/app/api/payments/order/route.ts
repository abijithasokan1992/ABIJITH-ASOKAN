import {NextResponse} from "next/server";
export const runtime="nodejs";
export async function POST(req:Request){
 const body=await req.json().catch(()=>({}));
 if(body.plan!=="vista_plus") return NextResponse.json({message:"Unknown plan."},{status:400});
 if(!process.env.RAZORPAY_KEY_ID||!process.env.RAZORPAY_KEY_SECRET) return NextResponse.json({message:"Razorpay server credentials are not configured. Add them to the Vercel Production environment before accepting live payments."},{status:503});
 const auth=Buffer.from(`${process.env.RAZORPAY_KEY_ID}:${process.env.RAZORPAY_KEY_SECRET}`).toString("base64");
 const r=await fetch("https://api.razorpay.com/v1/orders",{method:"POST",headers:{"Authorization":`Basic ${auth}`,"Content-Type":"application/json"},body:JSON.stringify({amount:19900,currency:"INR",receipt:`sv_${crypto.randomUUID()}`,notes:{product:"vista_plus"}}),cache:"no-store"});
 if(!r.ok)return NextResponse.json({message:"Payment order creation failed."},{status:502});
 const order=await r.json(); return NextResponse.json({orderId:order.id,keyId:process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID||process.env.RAZORPAY_KEY_ID});
}
