import {createHmac,timingSafeEqual} from "crypto"; import {createClient} from "@supabase/supabase-js"; import {NextResponse} from "next/server";
export const runtime="nodejs";
function verify(raw:string,signature:string,secret:string){const a=createHmac("sha256",secret).update(raw).digest("hex");const x=Buffer.from(a,"utf8"),y=Buffer.from(signature||"","utf8");return x.length===y.length&&timingSafeEqual(x,y);}
export async function POST(req:Request){
 const raw=await req.text(); const sig=req.headers.get("x-razorpay-signature")||""; const eventId=req.headers.get("x-razorpay-event-id")||"";
 if(!process.env.RAZORPAY_WEBHOOK_SECRET||!verify(raw,sig,process.env.RAZORPAY_WEBHOOK_SECRET))return NextResponse.json({error:"invalid signature"},{status:401});
 if(!eventId)return NextResponse.json({error:"missing event identity"},{status:400});
 const admin=createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!,process.env.SUPABASE_SERVICE_ROLE_KEY!,{auth:{autoRefreshToken:false,persistSession:false}});
 const payload=JSON.parse(raw); const eventType=String(payload.event||"unknown"); const payment=payload.payload?.payment?.entity||{}; const order=payload.payload?.order?.entity||{};
 const {data:existing}=await admin.from("payment_webhook_events").select("id").eq("event_id",eventId).maybeSingle();
 if(existing)return NextResponse.json({ok:true,duplicate:true});
 const {error:ledgerError}=await admin.from("payment_webhook_events").insert({event_id:eventId,event_type:eventType,payload});
 if(ledgerError)return NextResponse.json({error:"event ledger rejected"},{status:409});
 await admin.from("audit_logs").insert({actor_type:"razorpay",action:eventType,entity_type:"payment",entity_id:payment.id||order.id||eventId,metadata:{event_id:eventId,order_id:order.id||payment.order_id||null,payment_id:payment.id||null}});
 if(eventType==="payment.captured"&&payment.order_id){
   await admin.from("transactions").upsert({provider_order_id:payment.order_id,provider_payment_id:payment.id,state:"captured",amount_paise:Number(payment.amount||0),currency:payment.currency||"INR"},{onConflict:"provider_order_id"});
 }
 return NextResponse.json({ok:true});
}
