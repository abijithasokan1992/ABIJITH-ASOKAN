import "./globals.css";
export const metadata = {
  title: "Stream Vista OPC — Kerala Creator OTT",
  description: "Kerala's creator-first OTT and film commerce platform.",
  metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL || "https://streamvistaopc.com"),
  manifest: "/manifest.json"
};
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}
