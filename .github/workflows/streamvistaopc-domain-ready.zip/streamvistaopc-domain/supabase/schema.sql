create extension if not exists pgcrypto;

create type public.app_role as enum ('creator','producer','support','admin');
create type public.title_status as enum ('draft','in_production','published','archived');
create type public.transaction_state as enum ('pending','authorized','captured','failed','refunded');

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text,
 role public.app_role not null default 'creator',
 avatar_url text,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create table if not exists public.titles (
 id uuid primary key default gen_random_uuid(),
 owner_id uuid not null references public.profiles(id) on delete cascade,
 title text not null,
 slug text unique not null,
 description text not null default '',
 content_type text not null default 'film',
 status public.title_status not null default 'draft',
 cover_url text,
 playback_url text,
 views bigint not null default 0,
 created_at timestamptz not null default now()
);

create table if not exists public.subscriptions (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 plan text not null default 'vista_plus',
 provider_subscription_id text unique,
 state text not null default 'pending',
 current_period_end timestamptz,
 created_at timestamptz not null default now()
);

create table if not exists public.transactions (
 id uuid primary key default gen_random_uuid(),
 user_id uuid references public.profiles(id) on delete set null,
 title_id uuid references public.titles(id) on delete set null,
 model text not null check(model in ('subscription','ppv','commission')),
 provider_order_id text unique,
 provider_payment_id text unique,
 amount_paise bigint not null check(amount_paise >= 0),
 currency text not null default 'INR',
 state public.transaction_state not null default 'pending',
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create table if not exists public.payment_webhook_events (
 id uuid primary key default gen_random_uuid(),
 event_id text unique not null,
 event_type text not null,
 payload jsonb not null,
 received_at timestamptz not null default now()
);

create table if not exists public.audit_logs (
 id bigint generated always as identity primary key,
 actor_type text not null,
 actor_id uuid,
 action text not null,
 entity_type text not null,
 entity_id text,
 metadata jsonb not null default '{}'::jsonb,
 created_at timestamptz not null default now()
);

create table if not exists public.agent_runs (
 id uuid primary key default gen_random_uuid(),
 owner_id uuid references public.profiles(id) on delete set null,
 agent_key text not null check(agent_key in ('content','sales','operations')),
 idempotency_key text unique,
 status text not null default 'queued',
 input jsonb not null default '{}',
 output jsonb not null default '{}',
 created_at timestamptz not null default now(),
 completed_at timestamptz
);

alter table public.profiles enable row level security;
alter table public.titles enable row level security;
alter table public.subscriptions enable row level security;
alter table public.transactions enable row level security;
alter table public.payment_webhook_events enable row level security;
alter table public.audit_logs enable row level security;
alter table public.agent_runs enable row level security;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin'); $$;

create policy "profile owner select" on public.profiles for select using(auth.uid()=id or public.is_admin());
create policy "profile owner update" on public.profiles for update using(auth.uid()=id or public.is_admin());

create policy "published titles readable" on public.titles for select using(status='published' or owner_id=auth.uid() or public.is_admin());
create policy "title owner insert" on public.titles for insert with check(owner_id=auth.uid());
create policy "title owner update" on public.titles for update using(owner_id=auth.uid() or public.is_admin());
create policy "title owner delete" on public.titles for delete using(owner_id=auth.uid() or public.is_admin());

create policy "subscription owner read" on public.subscriptions for select using(user_id=auth.uid() or public.is_admin());
create policy "transaction owner read" on public.transactions for select using(user_id=auth.uid() or public.is_admin());
create policy "webhook events admin read" on public.payment_webhook_events for select using(public.is_admin());
create policy "audit admin read" on public.audit_logs for select using(public.is_admin());
create policy "agent owner read" on public.agent_runs for select using(owner_id=auth.uid() or public.is_admin());
create policy "agent owner insert" on public.agent_runs for insert with check(owner_id=auth.uid());

revoke all on public.payment_webhook_events from anon, authenticated;
revoke all on public.audit_logs from anon, authenticated;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public
as $$ begin insert into public.profiles(id,full_name) values(new.id,coalesce(new.raw_user_meta_data->>'full_name','')); return new; end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

create index if not exists titles_owner_idx on public.titles(owner_id);
create index if not exists titles_status_idx on public.titles(status);
create index if not exists transactions_order_idx on public.transactions(provider_order_id);
create index if not exists audit_entity_idx on public.audit_logs(entity_type,entity_id,created_at desc);
create index if not exists webhook_event_idx on public.payment_webhook_events(event_id);
