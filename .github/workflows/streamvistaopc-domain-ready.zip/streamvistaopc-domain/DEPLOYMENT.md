# Stream Vista OPC — streamvistaopc.com

## GitHub → Vercel

1. Push this repository to the Stream Vista GitHub repository.
2. In Vercel, import the GitHub repository.
3. Framework: Next.js is detected automatically.
4. Add these Production environment variables from `.env.example`.
5. Deploy the production branch.
6. In Vercel Project → Settings → Domains, add:
   - `streamvistaopc.com`
   - `www.streamvistaopc.com`
7. Choose the canonical domain in Vercel and redirect the other domain to it.

## GoDaddy DNS

For the apex domain:
- Type: A
- Host: @
- Value: `76.76.21.21`

For `www`:
- Type: CNAME
- Host: www
- Value: use the exact CNAME target shown by the Vercel Domains panel.

Remove conflicting A/CNAME records for the same hosts. Keep unrelated MX/TXT records required for email.

## Cloudflare DNS

Add:
- A `@` → `76.76.21.21`
- CNAME `www` → the exact Vercel CNAME target shown in the project Domains panel.

Use DNS-only during initial Vercel verification if Cloudflare proxying interferes with verification. After verification, enable proxying only if the resulting configuration remains compatible with Vercel.

## Supabase

1. Run `supabase/schema.sql` in the Supabase SQL editor or through your migration pipeline.
2. Add `https://streamvistaopc.com` and `https://www.streamvistaopc.com` to Supabase Auth URL configuration.
3. Configure the production redirect URL used by magic-link authentication.

## Razorpay

Server-only:
- `RAZORPAY_KEY_ID`
- `RAZORPAY_KEY_SECRET`
- `RAZORPAY_WEBHOOK_SECRET`

Public:
- `NEXT_PUBLIC_RAZORPAY_KEY_ID`

Configure Razorpay webhook endpoint:
`https://streamvistaopc.com/api/payments/webhook`

The webhook verifies `x-razorpay-signature`, requires an event identity, stores the event under a unique constraint, writes an audit record, and only then mutates captured transaction state.

## Domain note

The requested domain list is stored in `domain-manifest.json`. Current Vercel configuration documentation does not list `domains` as a supported `vercel.json` property; Vercel's supported production mechanism is Project Settings → Domains or the `vercel domains add` command. The deployable `vercel.json` therefore uses only supported configuration keys so the deployment does not fail schema validation.
