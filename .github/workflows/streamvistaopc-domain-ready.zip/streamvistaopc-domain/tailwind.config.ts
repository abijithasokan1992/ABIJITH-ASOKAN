import type { Config } from "tailwindcss";
export default {
  darkMode: ["class"],
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: { brand: "#dfff45" },
      boxShadow: { neon: "0 0 55px rgba(223,255,69,.13)" }
    }
  }
} satisfies Config;
