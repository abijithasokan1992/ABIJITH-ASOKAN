# Stream Vista OPC

Kerala Creator OTT for streamvistaopc.com.

Features:
- Premium OTT landing page
- Creator magic-link authentication
- Browse library
- Video player UI
- Subscription checkout endpoint prepared for Razorpay
- Server-side Razorpay webhook verification + idempotent event ledger
- Creator dashboard
- Admin control plane
- Supabase PostgreSQL + RLS
- Append-only audit log
- PWA manifest
- Vercel domain configuration companion manifest

Production deployment is documented in DEPLOYMENT.md.
